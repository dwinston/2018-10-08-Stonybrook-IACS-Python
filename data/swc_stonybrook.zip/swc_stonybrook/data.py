import json
import os

data_dir = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "data_files")

def loadfn(fn, data_dir=data_dir):
    """Load json from filename FN in DATA_DIR directory."""
    with open(os.path.join(data_dir, fn)) as f:
        return json.load(f)

atomic_weights = loadfn("atomic_weights.json")
atomic_numbers = loadfn("atomic_numbers.json")
crystals = loadfn("crystals.json")

with open(os.path.join(data_dir, "words")) as f:
    words = [line for line in f]
